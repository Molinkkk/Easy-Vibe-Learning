'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Play,
  RotateCcw,
  Pause,
  Trophy,
  Apple,
  Gauge,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Zap,
  Target,
  Flame,
  Sparkles,
  Gamepad2,
} from 'lucide-react'

// ============ 类型定义 ============
type Point = { x: number; y: number }
type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT'
type GameStatus = 'idle' | 'countdown' | 'playing' | 'paused' | 'over'
type CountdownStage = '3' | '2' | '1' | 'GO'

// 道具类型
type ItemType =
  | 'shield'    // 正：护盾
  | 'boost'     // 正：加速
  | 'double'    // 正：双倍分
  | 'shrink'    // 正：缩短身体
  | 'freeze'    // 正：Combo 冻结
  | 'poison'    // 负：毒蘑菇
  | 'reverse'   // 负：反向控制
  | 'slow'      // 负：减速
  | 'fog'       // 负：视野受限

type ActiveBuff = {
  type: ItemType
  expiresAt: number
  duration: number
  // 护盾是消耗品：剩余次数
  shieldCharges?: number
}

type PowerUpItem = {
  pos: Point
  type: ItemType
  expiresAt: number // 道具本身的存在时间
}

type FloatingText = {
  id: number
  text: string
  subText?: string
  x: number // 画布坐标（像素）
  y: number
  color: string
  size: number
  bornAt: number
}

type Achievement = {
  id: string
  name: string
  icon: string
  condition: string
  description: string
}

// ============ 常量 ============
const GRID_SIZE = 20
const CELL_SIZE = 32
const CANVAS_SIZE = GRID_SIZE * CELL_SIZE

const SPEED_MAP: Record<number, number> = {
  1: 180,
  2: 140,
  3: 100,
  4: 70,
}

const INITIAL_SNAKE: Point[] = [
  { x: 8, y: 10 },
  { x: 7, y: 10 },
  { x: 6, y: 10 },
]

const OPPOSITE: Record<Direction, Direction> = {
  UP: 'DOWN',
  DOWN: 'UP',
  LEFT: 'RIGHT',
  RIGHT: 'LEFT',
}

// Combo 窗口
const COMBO_WINDOW_MS = 3000
const COMBO_WINDOW_MAX_MS = 5000 // 链长奖励上限

// Fever 触发：连吃 8 个（对应 5× 倍率）
const FEVER_TRIGGER_COMBO = 8
const FEVER_DURATION_MS = 6000

// 倍率阶梯
const COMBO_TIERS: { count: number; multiplier: number; color: string }[] = [
  { count: 1, multiplier: 1, color: '#ffffff' },
  { count: 2, multiplier: 1.5, color: '#ffffff' },
  { count: 3, multiplier: 2, color: '#FEF3C7' },
  { count: 5, multiplier: 3, color: '#FDE047' },
  { count: 8, multiplier: 5, color: '#FB923C' },
  { count: 12, multiplier: 8, color: '#EF4444' },
  { count: 16, multiplier: 12, color: '#A855F7' },
  { count: 20, multiplier: 20, color: 'rainbow' },
]

// 成就定义
const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_combo_3',
    name: '初尝甜头',
    icon: '🔥',
    condition: 'single_combo_3',
    description: '单局达到 3× Combo',
  },
  {
    id: 'combo_master_8',
    name: 'Combo 大师',
    icon: '⚡',
    condition: 'single_combo_8',
    description: '单局达到 8× Combo',
  },
  {
    id: 'perfect_20',
    name: '完美主义',
    icon: '💎',
    condition: 'single_combo_20',
    description: '单局达到 20× Combo',
  },
  {
    id: 'sniper_5',
    name: '神射手',
    icon: '🏹',
    condition: 'single_sniper_5',
    description: '单局触发 5 次 Snipe',
  },
  {
    id: 'dancer_10',
    name: '舞者',
    icon: '💃',
    condition: 'single_trick_10',
    description: '单局触发 10 次 Trick',
  },
  {
    id: 'clutch_3',
    name: '惊险大师',
    icon: '🤡',
    condition: 'single_clutch_3',
    description: '单局触发 3 次 Clutch',
  },
  {
    id: 'first_fever',
    name: '第一缕光',
    icon: '🌈',
    condition: 'fever_triggered',
    description: '触发首次 Fever',
  },
  {
    id: 'volcano_5',
    name: '火山爆发',
    icon: '🌋',
    condition: 'fever_eat_5',
    description: 'Fever 期间吃到 5 个食物',
  },
]

// 基础分数
const BASE_FOOD_SCORE = 10

// ============ 道具配置 ============
type ItemConfig = {
  name: string
  icon: string
  color: string
  glowColor: string
  duration: number // 0 = 瞬时效果
  positive: boolean
  description: string
}

const ITEM_CONFIG: Record<ItemType, ItemConfig> = {
  shield: {
    name: '护盾',
    icon: '🛡️',
    color: '#3b82f6',
    glowColor: 'rgba(59, 130, 246, 0.6)',
    duration: 8000,
    positive: true,
    description: '8 秒内抵挡一次撞击',
  },
  boost: {
    name: '加速冲刺',
    icon: '⚡',
    color: '#fbbf24',
    glowColor: 'rgba(251, 191, 36, 0.6)',
    duration: 5000,
    positive: true,
    description: '5 秒蛇速 +50%，分数 +30%',
  },
  double: {
    name: '双倍分',
    icon: '💎',
    color: '#a855f7',
    glowColor: 'rgba(168, 85, 247, 0.6)',
    duration: 6000,
    positive: true,
    description: '6 秒内分数 ×2',
  },
  shrink: {
    name: '紧急缩短',
    icon: '✂️',
    color: '#10b981',
    glowColor: 'rgba(16, 185, 129, 0.6)',
    duration: 0,
    positive: true,
    description: '立即缩短身体 3 节',
  },
  freeze: {
    name: '时间冻结',
    icon: '❄️',
    color: '#06b6d4',
    glowColor: 'rgba(6, 182, 212, 0.6)',
    duration: 3000,
    positive: true,
    description: '3 秒内 Combo 倒计时暂停',
  },
  poison: {
    name: '毒蘑菇',
    icon: '💀',
    color: '#6b21a8',
    glowColor: 'rgba(107, 33, 168, 0.7)',
    duration: 0,
    positive: false,
    description: '缩短 2 节，失去 30% 分数',
  },
  reverse: {
    name: '反向控制',
    icon: '🔄',
    color: '#dc2626',
    glowColor: 'rgba(220, 38, 38, 0.6)',
    duration: 5000,
    positive: false,
    description: '5 秒内方向键反向',
  },
  slow: {
    name: '减速',
    icon: '🐌',
    color: '#6b7280',
    glowColor: 'rgba(107, 114, 128, 0.6)',
    duration: 5000,
    positive: false,
    description: '5 秒蛇速 -50%',
  },
  fog: {
    name: '黑雾',
    icon: '🌫️',
    color: '#4b5563',
    glowColor: 'rgba(75, 85, 99, 0.7)',
    duration: 5000,
    positive: false,
    description: '5 秒视野受限',
  },
}

// 道具刷新间隔（毫秒）
const POWERUP_SPAWN_MIN = 12000
const POWERUP_SPAWN_MAX = 20000
// 道具存在时间
const POWERUP_LIFETIME = 10000

// 反向映射：方向键 → 反向后的方向
const REVERSE_DIR: Record<Direction, Direction> = {
  UP: 'DOWN',
  DOWN: 'UP',
  LEFT: 'RIGHT',
  RIGHT: 'LEFT',
}

// ============ 工具函数 ============
function manhattanDistance(a: Point, b: Point): number {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y)
}

function randomFood(snake: Point[], avoidHead?: Point, minDistance = 0): Point {
  const candidates: Point[] = []
  for (let x = 0; x < GRID_SIZE; x++) {
    for (let y = 0; y < GRID_SIZE; y++) {
      if (snake.some((s) => s.x === x && s.y === y)) continue
      if (avoidHead && manhattanDistance({ x, y }, avoidHead) < minDistance) continue
      candidates.push({ x, y })
    }
  }
  if (candidates.length === 0) {
    // 兜底：忽略距离限制
    for (let x = 0; x < GRID_SIZE; x++) {
      for (let y = 0; y < GRID_SIZE; y++) {
        if (snake.some((s) => s.x === x && s.y === y)) continue
        return { x, y }
      }
    }
    return { x: 0, y: 0 }
  }
  return candidates[Math.floor(Math.random() * candidates.length)]
}

function getComboTier(comboCount: number) {
  let tier = COMBO_TIERS[0]
  for (const t of COMBO_TIERS) {
    if (comboCount >= t.count) tier = t
  }
  return tier
}

function getSpeedMultiplier(comboMultiplier: number): number {
  if (comboMultiplier >= 12) return 2.0
  if (comboMultiplier >= 8) return 1.7
  if (comboMultiplier >= 5) return 1.4
  if (comboMultiplier >= 3) return 1.2
  return 1.0
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + radius, y)
  ctx.lineTo(x + w - radius, y)
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius)
  ctx.lineTo(x + w, y + h - radius)
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h)
  ctx.lineTo(x + radius, y + h)
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius)
  ctx.lineTo(x, y + radius)
  ctx.quadraticCurveTo(x, y, x + radius, y)
  ctx.closePath()
}

// ============ 主组件 ============
export default function SnakeGame() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const containerRef = useRef<HTMLDivElement | null>(null)

  // === 基础状态 ===
  const [snake, setSnake] = useState<Point[]>(INITIAL_SNAKE)
  const [foods, setFoods] = useState<Point[]>([{ x: 14, y: 10 }])
  const [direction, setDirection] = useState<Direction>('RIGHT')
  const [status, setStatus] = useState<GameStatus>('idle')
  const [countdownStage, setCountdownStage] = useState<CountdownStage | null>(null)
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(() => {
    if (typeof window === 'undefined') return 0
    const saved = localStorage.getItem('snake-high-score')
    return saved ? parseInt(saved, 10) || 0 : 0
  })
  const [level, setLevel] = useState(2)
  const [foodEaten, setFoodEaten] = useState(0)

  // === Combo 状态 ===
  const [comboCount, setComboCount] = useState(0)
  const [comboTimer, setComboTimer] = useState(0) // 剩余毫秒
  const [comboMultiplier, setComboMultiplier] = useState(1)

  // === Fever 状态 ===
  const [isFever, setIsFever] = useState(false)
  const [feverUsed, setFeverUsed] = useState(false)
  const [feverTimeLeft, setFeverTimeLeft] = useState(0)

  // === 隐性奖励统计 ===
  const [clutchCount, setClutchCount] = useState(0)
  const [sniperCount, setSniperCount] = useState(0)
  const [trickCount, setTrickCount] = useState(0)
  const [feverScore, setFeverScore] = useState(0)
  const [maxCombo, setMaxCombo] = useState(0)
  const [feverFoodsEaten, setFeverFoodsEaten] = useState(0)

  // === 道具系统 ===
  const [powerUpItem, setPowerUpItem] = useState<PowerUpItem | null>(null)
  const [activeBuffs, setActiveBuffs] = useState<ActiveBuff[]>([])
  const [itemsCollected, setItemsCollected] = useState(0)

  // === 飘字 ===
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([])
  const floatingIdRef = useRef(0)

  // === 成就 ===
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(() => {
    if (typeof window === 'undefined') return []
    const saved = localStorage.getItem('snake-achievements')
    return saved ? JSON.parse(saved) : []
  })
  const [achievementToast, setAchievementToast] = useState<Achievement | null>(null)
  const achievementQueueRef = useRef<Achievement[]>([])

  // === Refs（避免闭包过期）===
  const directionRef = useRef<Direction>('RIGHT')
  const nextDirectionRef = useRef<Direction>('RIGHT')
  const snakeRef = useRef<Point[]>(INITIAL_SNAKE)
  const foodsRef = useRef<Point[]>([{ x: 14, y: 10 }])
  const statusRef = useRef<GameStatus>('idle')
  const levelRef = useRef<number>(2)
  const scoreRef = useRef<number>(0)
  const highScoreRef = useRef<number>(0)
  const comboCountRef = useRef<number>(0)
  const comboTimerRef = useRef<number>(0)
  const isFeverRef = useRef<boolean>(false)
  const feverUsedRef = useRef<boolean>(false)
  const feverTimeLeftRef = useRef<number>(0)
  const lastEatTimeRef = useRef<number>(0)
  const lastDirectionChangeAtEatRef = useRef<boolean>(false)
  const directionChangeSinceLastEatRef = useRef<boolean>(false)
  const consecutiveDirectionCountRef = useRef<number>(0)
  const lastDirRef = useRef<Direction>('RIGHT')
  const statsRef = useRef({
    clutch: 0,
    sniper: 0,
    trick: 0,
    maxCombo: 0,
    feverTriggered: false,
    feverFoodsEaten: 0,
  })

  // 道具 refs
  const powerUpItemRef = useRef<PowerUpItem | null>(null)
  const activeBuffsRef = useRef<ActiveBuff[]>([])
  const nextPowerUpSpawnRef = useRef<number>(0)

  // === 同步 refs ===
  useEffect(() => { directionRef.current = direction }, [direction])
  useEffect(() => { snakeRef.current = snake }, [snake])
  useEffect(() => { foodsRef.current = foods }, [foods])
  useEffect(() => { statusRef.current = status }, [status])
  useEffect(() => { levelRef.current = level }, [level])
  useEffect(() => { scoreRef.current = score }, [score])
  useEffect(() => { highScoreRef.current = highScore }, [highScore])
  useEffect(() => { comboCountRef.current = comboCount }, [comboCount])
  useEffect(() => { comboTimerRef.current = comboTimer }, [comboTimer])
  useEffect(() => { isFeverRef.current = isFever }, [isFever])
  useEffect(() => { feverUsedRef.current = feverUsed }, [feverUsed])
  useEffect(() => { feverTimeLeftRef.current = feverTimeLeft }, [feverTimeLeft])
  useEffect(() => { powerUpItemRef.current = powerUpItem }, [powerUpItem])
  useEffect(() => { activeBuffsRef.current = activeBuffs }, [activeBuffs])

  // === 道具系统工具函数 ===
  const hasBuff = useCallback((type: ItemType) => {
    return activeBuffsRef.current.some((b) => b.type === type)
  }, [])

  // 应用道具效果
  const applyPowerUp = useCallback((type: ItemType, currentSnake: Point[]) => {
    const cfg = ITEM_CONFIG[type]
    const now = Date.now()

    // 瞬时效果
    if (type === 'shrink') {
      // 缩短身体 3 节（保留至少 3 节）
      const newSnake = currentSnake.slice(0, Math.max(3, currentSnake.length - 3))
      setSnake(newSnake)
      snakeRef.current = newSnake
    } else if (type === 'poison') {
      // 缩短 2 节，失去 30% 分数
      const newSnake = currentSnake.slice(0, Math.max(3, currentSnake.length - 2))
      setSnake(newSnake)
      snakeRef.current = newSnake
      const lostScore = Math.floor(scoreRef.current * 0.3)
      const newScore = scoreRef.current - lostScore
      setScore(newScore)
      scoreRef.current = newScore
    } else {
      // 持续型 buff
      const buff: ActiveBuff = {
        type,
        expiresAt: now + cfg.duration,
        duration: cfg.duration,
        shieldCharges: type === 'shield' ? 1 : undefined,
      }
      setActiveBuffs((prev) => {
        // 同类 buff 不叠加，刷新时间
        const filtered = prev.filter((b) => b.type !== type)
        return [...filtered, buff]
      })
    }

    // 统计
    setItemsCollected((c) => c + 1)
  }, [])

  // 检查并移除过期 buff
  const cleanExpiredBuffs = useCallback(() => {
    const now = Date.now()
    const expired = activeBuffsRef.current.filter((b) => b.expiresAt <= now)
    if (expired.length > 0) {
      setActiveBuffs((prev) => prev.filter((b) => b.expiresAt > now))
    }
  }, [])

  // === 飘字添加 ===
  const addFloatingText = useCallback(
    (text: string, subText: string | undefined, gridX: number, gridY: number, color: string, size: number) => {
      const id = floatingIdRef.current++
      const ft: FloatingText = {
        id,
        text,
        subText,
        x: gridX * CELL_SIZE + CELL_SIZE / 2,
        y: gridY * CELL_SIZE,
        color,
        size,
        bornAt: Date.now(),
      }
      setFloatingTexts((prev) => [...prev, ft])
      // 1.2 秒后移除
      setTimeout(() => {
        setFloatingTexts((prev) => prev.filter((f) => f.id !== id))
      }, 1200)
    },
    []
  )

  // === 成就解锁 ===
  const unlockAchievement = useCallback((id: string) => {
    setUnlockedAchievements((prev) => {
      if (prev.includes(id)) return prev
      const next = [...prev, id]
      localStorage.setItem('snake-achievements', JSON.stringify(next))
      const ach = ACHIEVEMENTS.find((a) => a.id === id)
      if (ach) {
        achievementQueueRef.current.push(ach)
      }
      return next
    })
  }, [])

  // 显示队列中的成就
  useEffect(() => {
    if (achievementToast || achievementQueueRef.current.length === 0) return
    const next = achievementQueueRef.current.shift()
    if (next) {
      setAchievementToast(next)
      setTimeout(() => {
        setAchievementToast(null)
      }, 3500)
    }
  }, [achievementToast])

  // 检查成就解锁条件（每次吃到食物后调用）
  const checkAchievements = useCallback(() => {
    const s = statsRef.current
    if (s.maxCombo >= 3) unlockAchievement('first_combo_3')
    if (s.maxCombo >= 8) unlockAchievement('combo_master_8')
    if (s.maxCombo >= 20) unlockAchievement('perfect_20')
    if (s.sniper >= 5) unlockAchievement('sniper_5')
    if (s.trick >= 10) unlockAchievement('dancer_10')
    if (s.clutch >= 3) unlockAchievement('clutch_3')
    if (s.feverTriggered) unlockAchievement('first_fever')
    if (s.feverFoodsEaten >= 5) unlockAchievement('volcano_5')
  }, [unlockAchievement])

  // ============ 绘制 Canvas ============
  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const fever = isFeverRef.current
    const comboMult = comboCountRef.current > 0 ? getComboTier(comboCountRef.current).multiplier : 1

    // 背景（Fever 时变紫）
    if (fever) {
      const bgGrad = ctx.createLinearGradient(0, 0, CANVAS_SIZE, CANVAS_SIZE)
      bgGrad.addColorStop(0, '#1a0033')
      bgGrad.addColorStop(0.5, '#2d1b69')
      bgGrad.addColorStop(1, '#1a0033')
      ctx.fillStyle = bgGrad
    } else if (comboMult >= 8) {
      ctx.fillStyle = '#1a0a0a'
    } else if (comboMult >= 3) {
      ctx.fillStyle = '#1a1408'
    } else {
      ctx.fillStyle = '#0f172a'
    }
    ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE)

    // 网格线
    ctx.strokeStyle = fever
      ? 'rgba(255, 215, 0, 0.12)'
      : 'rgba(148, 163, 184, 0.08)'
    ctx.lineWidth = 1
    for (let i = 1; i < GRID_SIZE; i++) {
      ctx.beginPath()
      ctx.moveTo(i * CELL_SIZE, 0)
      ctx.lineTo(i * CELL_SIZE, CANVAS_SIZE)
      ctx.stroke()
      ctx.beginPath()
      ctx.moveTo(0, i * CELL_SIZE)
      ctx.lineTo(CANVAS_SIZE, i * CELL_SIZE)
      ctx.stroke()
    }

    // Fever 期间画金色边框
    if (fever) {
      ctx.strokeStyle = 'rgba(255, 215, 0, 0.6)'
      ctx.lineWidth = 3
      ctx.strokeRect(2, 2, CANVAS_SIZE - 4, CANVAS_SIZE - 4)
    }

    const currentSnake = snakeRef.current
    const currentFoods = foodsRef.current

    // === 画食物 ===
    const time = Date.now()
    currentFoods.forEach((food) => {
      const fx = food.x * CELL_SIZE + CELL_SIZE / 2
      const fy = food.y * CELL_SIZE + CELL_SIZE / 2
      // Fever 期间食物脉动
      const pulseScale = fever ? 1 + Math.sin(time / 200) * 0.15 : 1
      const r = (CELL_SIZE / 2 - 2) * pulseScale

      // 外发光
      const glowColor = fever ? '255, 215, 0' : '244, 63, 94'
      const glow = ctx.createRadialGradient(fx, fy, r * 0.2, fx, fy, r * 2)
      glow.addColorStop(0, `rgba(${glowColor}, 0.55)`)
      glow.addColorStop(1, `rgba(${glowColor}, 0)`)
      ctx.fillStyle = glow
      ctx.beginPath()
      ctx.arc(fx, fy, r * 2, 0, Math.PI * 2)
      ctx.fill()

      // 食物本体
      const grad = ctx.createRadialGradient(
        fx - r * 0.3,
        fy - r * 0.3,
        r * 0.1,
        fx,
        fy,
        r
      )
      if (fever) {
        grad.addColorStop(0, '#fef3c7')
        grad.addColorStop(1, '#f59e0b')
      } else {
        grad.addColorStop(0, '#fda4af')
        grad.addColorStop(1, '#e11d48')
      }
      ctx.fillStyle = grad
      ctx.beginPath()
      ctx.arc(fx, fy, r, 0, Math.PI * 2)
      ctx.fill()
    })

    // === 画道具 ===
    const currentPowerUp = powerUpItemRef.current
    if (currentPowerUp) {
      const cfg = ITEM_CONFIG[currentPowerUp.type]
      const px = currentPowerUp.pos.x * CELL_SIZE + CELL_SIZE / 2
      const py = currentPowerUp.pos.y * CELL_SIZE + CELL_SIZE / 2
      const pulseScale = 1 + Math.sin(time / 200) * 0.12
      const pr = (CELL_SIZE / 2 - 3) * pulseScale
      // 剩余时间百分比（用于闪烁警告）
      const lifeRatio = (currentPowerUp.expiresAt - time) / POWERUP_LIFETIME
      const blink = lifeRatio < 0.3 ? (Math.sin(time / 100) > 0 ? 1 : 0.3) : 1

      // 外发光
      const pGlow = ctx.createRadialGradient(px, py, pr * 0.2, px, py, pr * 2.5)
      pGlow.addColorStop(0, cfg.glowColor)
      pGlow.addColorStop(1, 'rgba(0, 0, 0, 0)')
      ctx.globalAlpha = blink
      ctx.fillStyle = pGlow
      ctx.beginPath()
      ctx.arc(px, py, pr * 2.5, 0, Math.PI * 2)
      ctx.fill()

      // 旋转的六边形道具底
      ctx.save()
      ctx.translate(px, py)
      ctx.rotate(time / 800)
      ctx.fillStyle = cfg.color
      ctx.shadowColor = cfg.color
      ctx.shadowBlur = 15
      ctx.beginPath()
      for (let i = 0; i < 6; i++) {
        const angle = (i / 6) * Math.PI * 2
        const x = Math.cos(angle) * pr
        const y = Math.sin(angle) * pr
        if (i === 0) ctx.moveTo(x, y)
        else ctx.lineTo(x, y)
      }
      ctx.closePath()
      ctx.fill()
      // 内层高亮
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)'
      ctx.beginPath()
      ctx.arc(-pr * 0.3, -pr * 0.3, pr * 0.35, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
      ctx.shadowBlur = 0

      // 道具图标（用 canvas 文本绘制 emoji）
      ctx.globalAlpha = blink
      ctx.font = `${Math.floor(CELL_SIZE * 0.7)}px sans-serif`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText(cfg.icon, px, py + 1)
      ctx.globalAlpha = 1
    }

    // === 画蛇（根据 buff 显示不同状态）===
    const hueRef = (time / 20) % 360
    // 获取当前激活的 buff 类型（用于蛇身颜色）
    const buffs = activeBuffsRef.current
    const hasShield = buffs.some((b) => b.type === 'shield')
    const hasBoost = buffs.some((b) => b.type === 'boost')
    const hasDouble = buffs.some((b) => b.type === 'double')
    const hasReverse = buffs.some((b) => b.type === 'reverse')
    const hasSlow = buffs.some((b) => b.type === 'slow')
    const hasFreeze = buffs.some((b) => b.type === 'freeze')

    // 决定蛇身主色（优先级：fever > shield > reverse > double > boost > freeze > slow > normal）
    let snakeMainColor = '#10b981' // 默认绿
    let snakeBodyColorBase = { r: 16, g: 185, b: 129 }
    if (hasShield) {
      snakeMainColor = '#3b82f6'
      snakeBodyColorBase = { r: 37, g: 99, b: 235 }
    } else if (hasReverse) {
      snakeMainColor = '#dc2626'
      snakeBodyColorBase = { r: 220, g: 38, b: 38 }
    } else if (hasDouble) {
      snakeMainColor = '#a855f7'
      snakeBodyColorBase = { r: 168, g: 85, b: 247 }
    } else if (hasBoost) {
      snakeMainColor = '#fbbf24'
      snakeBodyColorBase = { r: 245, g: 158, b: 11 }
    } else if (hasFreeze) {
      snakeMainColor = '#06b6d4'
      snakeBodyColorBase = { r: 6, g: 182, b: 212 }
    } else if (hasSlow) {
      snakeMainColor = '#6b7280'
      snakeBodyColorBase = { r: 107, g: 114, b: 128 }
    }

    currentSnake.forEach((segment, index) => {
      const x = segment.x * CELL_SIZE
      const y = segment.y * CELL_SIZE
      const isHead = index === 0

      let fillColor: string
      if (fever) {
        // Fever 期间彩虹色
        const hue = (hueRef + index * 20) % 360
        fillColor = `hsl(${hue}, 90%, 60%)`
        ctx.shadowColor = `hsla(${hue}, 90%, 60%, 0.8)`
        ctx.shadowBlur = isHead ? 18 : 10
      } else {
        // 颜色：从头部亮色渐变到尾部深色，Combo 越高越亮
        const t = currentSnake.length > 1 ? index / (currentSnake.length - 1) : 0
        const intensityBoost = Math.min(comboMult / 8, 1) * 30
        const baseR = snakeBodyColorBase.r
        const baseG = Math.round(snakeBodyColorBase.g - t * 60 + intensityBoost)
        const baseB = Math.round(snakeBodyColorBase.b - t * 40 + intensityBoost * 0.5)
        if (isHead) {
          ctx.shadowColor = `${snakeMainColor}99`
          ctx.shadowBlur = 12
          fillColor = snakeMainColor
        } else {
          ctx.shadowBlur = 0
          fillColor = `rgb(${baseR}, ${baseG}, ${baseB})`
        }
      }

      ctx.fillStyle = fillColor
      const pad = isHead ? 1 : 2
      const radius = isHead ? 8 : 6
      roundRect(ctx, x + pad, y + pad, CELL_SIZE - pad * 2, CELL_SIZE - pad * 2, radius)
      ctx.fill()
      ctx.shadowBlur = 0

      // 护盾激活时蛇头加圆环
      if (isHead && hasShield) {
        ctx.strokeStyle = '#3b82f6'
        ctx.lineWidth = 2
        ctx.shadowColor = '#3b82f6'
        ctx.shadowBlur = 8
        ctx.beginPath()
        ctx.arc(x + CELL_SIZE / 2, y + CELL_SIZE / 2, CELL_SIZE / 2 + 4, 0, Math.PI * 2)
        ctx.stroke()
        ctx.shadowBlur = 0
      }

      // Freeze 时蛇身加冰晶装饰
      if (hasFreeze && !isHead) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.5)'
        ctx.beginPath()
        ctx.arc(x + CELL_SIZE / 2, y + CELL_SIZE / 2, 2, 0, Math.PI * 2)
        ctx.fill()
      }

      // 蛇头画眼睛
      if (isHead) {
        const dir = directionRef.current
        ctx.fillStyle = fever ? '#1a0033' : '#0f172a'
        const eyeOffset = 6
        const eyeR = 2.5
        let eyes: [number, number][]
        if (dir === 'RIGHT') {
          eyes = [
            [x + CELL_SIZE - eyeOffset, y + 7],
            [x + CELL_SIZE - eyeOffset, y + CELL_SIZE - 7],
          ]
        } else if (dir === 'LEFT') {
          eyes = [
            [x + eyeOffset, y + 7],
            [x + eyeOffset, y + CELL_SIZE - 7],
          ]
        } else if (dir === 'UP') {
          eyes = [
            [x + 7, y + eyeOffset],
            [x + CELL_SIZE - 7, y + eyeOffset],
          ]
        } else {
          eyes = [
            [x + 7, y + CELL_SIZE - eyeOffset],
            [x + CELL_SIZE - 7, y + CELL_SIZE - eyeOffset],
          ]
        }
        eyes.forEach(([ex, ey]) => {
          ctx.beginPath()
          ctx.arc(ex, ey, eyeR, 0, Math.PI * 2)
          ctx.fill()
        })
      }
    })

    // === Combo 警告光环（Combo 高时）===
    if (comboMult >= 5 && !fever) {
      const alpha = 0.15 + Math.sin(time / 150) * 0.05
      ctx.strokeStyle = `rgba(251, 146, 60, ${alpha})`
      ctx.lineWidth = 6
      ctx.strokeRect(3, 3, CANVAS_SIZE - 6, CANVAS_SIZE - 6)
    }

    // === Fog 黑雾效果（视野受限）===
    if (activeBuffsRef.current.some((b) => b.type === 'fog')) {
      const head = currentSnake[0]
      const hx = head.x * CELL_SIZE + CELL_SIZE / 2
      const hy = head.y * CELL_SIZE + CELL_SIZE / 2
      const visibleRadius = CELL_SIZE * 3.5
      const fogGrad = ctx.createRadialGradient(hx, hy, visibleRadius * 0.5, hx, hy, visibleRadius * 1.5)
      fogGrad.addColorStop(0, 'rgba(0, 0, 0, 0)')
      fogGrad.addColorStop(0.6, 'rgba(0, 0, 0, 0.5)')
      fogGrad.addColorStop(1, 'rgba(0, 0, 0, 0.95)')
      ctx.fillStyle = fogGrad
      ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE)
    }
  }, [])

  // ============ 游戏主循环 ============
  useEffect(() => {
    if (status !== 'playing') return

    const baseInterval = SPEED_MAP[levelRef.current]
    const comboMult = comboCountRef.current > 0 ? getComboTier(comboCountRef.current).multiplier : 1
    let speedMult = isFeverRef.current ? 1.0 : getSpeedMultiplier(comboMult) // Fever 期间不加速
    // 加速 buff
    if (activeBuffsRef.current.some((b) => b.type === 'boost')) speedMult *= 1.5
    // 减速 buff
    if (activeBuffsRef.current.some((b) => b.type === 'slow')) speedMult *= 0.5
    const interval = Math.max(40, baseInterval / speedMult)

    const tick = () => {
      const dir = nextDirectionRef.current
      const currentSnake = snakeRef.current
      const currentFoods = foodsRef.current
      const fever = isFeverRef.current
      const currentPowerUp = powerUpItemRef.current

      const head = currentSnake[0]
      const next = { x: head.x, y: head.y }
      if (dir === 'UP') next.y -= 1
      if (dir === 'DOWN') next.y += 1
      if (dir === 'LEFT') next.x -= 1
      if (dir === 'RIGHT') next.x += 1

      // 检查是否吃到食物
      const eatenFoodIndex = currentFoods.findIndex((f) => f.x === next.x && f.y === next.y)
      const willEat = eatenFoodIndex >= 0

      // 检查是否吃到道具
      const willPickUpPowerUp = !!currentPowerUp && currentPowerUp.pos.x === next.x && currentPowerUp.pos.y === next.y

      // === 碰撞检测 ===
      let collided = false
      // 撞墙
      if (
        next.x < 0 ||
        next.x >= GRID_SIZE ||
        next.y < 0 ||
        next.y >= GRID_SIZE
      ) {
        collided = true
      }
      // 撞自己
      if (!collided) {
        const bodyToCheck = willEat || willPickUpPowerUp
          ? currentSnake
          : currentSnake.slice(0, currentSnake.length - 1)
        if (bodyToCheck.some((s) => s.x === next.x && s.y === next.y)) {
          collided = true
        }
      }

      // Fever 期间不死
      if (collided && fever) {
        return
      }

      // 护盾激活：消耗一次护盾，本次不死，蛇头不动
      if (collided) {
        const shieldIdx = activeBuffsRef.current.findIndex((b) => b.type === 'shield' && (b.shieldCharges ?? 0) > 0)
        if (shieldIdx >= 0) {
          // 消耗护盾
          setActiveBuffs((prev) => {
            const next = [...prev]
            const s = next[shieldIdx]
            if (s.shieldCharges && s.shieldCharges > 0) {
              next[shieldIdx] = { ...s, shieldCharges: s.shieldCharges - 1 }
            }
            return next.filter((b) => (b.shieldCharges ?? 1) > 0)
          })
          addFloatingText('🛡️ SHIELD!', '护盾消耗', head.x, head.y, '#3b82f6', 24)
          // 蛇头不动，但其他逻辑继续
          return
        }
        setStatus('over')
        return
      }

      const newSnake = [next, ...(willEat ? currentSnake : currentSnake.slice(0, -1))]

      // 方向变化检测（用于 Trickster 奖励）
      const dirChanged = dir !== lastDirRef.current
      if (dirChanged) {
        directionChangeSinceLastEatRef.current = true
        consecutiveDirectionCountRef.current = 0
      } else {
        consecutiveDirectionCountRef.current += 1
      }
      lastDirRef.current = dir

      directionRef.current = dir
      setDirection(dir)
      setSnake(newSnake)

      // === 拾取道具 ===
      if (willPickUpPowerUp && currentPowerUp) {
        const itemType = currentPowerUp.type
        const cfg = ITEM_CONFIG[itemType]
        applyPowerUp(itemType, newSnake)

        // 道具消失
        setPowerUpItem(null)
        powerUpItemRef.current = null

        // 飘字
        const isPositive = cfg.positive
        addFloatingText(
          `${cfg.icon} ${cfg.name}`,
          isPositive ? '+BUFF' : '-DEBUFF',
          currentPowerUp.pos.x,
          currentPowerUp.pos.y,
          cfg.color,
          20
        )
      }

      // === 吃食物逻辑 ===
      if (willEat) {
        const now = Date.now()
        const food = currentFoods[eatenFoodIndex]

        // Combo 计算
        const prevComboCount = comboCountRef.current
        const newComboCount = prevComboCount + 1

        // Combo 窗口判断
        const prevTimer = comboTimerRef.current
        const comboStillActive = prevComboCount > 0 && prevTimer > 0

        // 检测险胜（剩余时间 < 500ms）
        const isClutch = prevComboCount > 0 && prevTimer > 0 && prevTimer < 500

        // 检测远距离
        const dist = manhattanDistance(head, food)
        const isSniper = dist >= 5

        // 检测方向变化
        const isTrick = directionChangeSinceLastEatRef.current

        // Combo 重置/续接
        const comboTimerMax = Math.min(
          COMBO_WINDOW_MAX_MS,
          COMBO_WINDOW_MS + Math.floor(newComboCount / 5) * 500
        )
        const newComboTimer = comboStillActive ? comboTimerMax : comboTimerMax

        const newTier = getComboTier(newComboCount)
        const newComboMultiplier = newTier.multiplier

        // 计算分数
        let earnedScore = BASE_FOOD_SCORE
        // Combo 倍率
        earnedScore *= newComboMultiplier
        // 险胜奖励
        if (isClutch) earnedScore *= 1.5
        // 远距离奖励
        if (isSniper) earnedScore *= 1.3
        // 方向变化奖励
        if (isTrick) earnedScore *= 1.2
        // 加速 buff：+30%
        if (hasBuff('boost')) earnedScore *= 1.3
        // 双倍分 buff：×2
        if (hasBuff('double')) earnedScore *= 2
        // Fever 期间双倍
        if (fever) earnedScore *= 2

        const finalScore = Math.round(earnedScore)

        // 飘字
        const tier = newTier
        const subText: string[] = []
        if (isClutch) subText.push('⚡CLUTCH')
        if (isSniper) subText.push('🏹SNIPER')
        if (isTrick) subText.push('🔄TRICK')
        if (hasBuff('boost')) subText.push('⚡BOOST')
        if (hasBuff('double')) subText.push('💎DOUBLE')
        if (fever) subText.push('🌈FEVER×2')

        const fontSize = Math.min(28, 14 + newComboMultiplier)
        addFloatingText(
          `+${finalScore}`,
          subText.length > 0 ? subText.join(' ') : undefined,
          food.x,
          food.y,
          tier.color === 'rainbow' ? '#fbbf24' : tier.color,
          fontSize
        )

        // 更新分数
        const newScore = scoreRef.current + finalScore
        setScore(newScore)
        if (fever) {
          setFeverScore((s) => s + finalScore)
          setFeverFoodsEaten((c) => c + 1)
          statsRef.current.feverFoodsEaten += 1
        }

        if (newScore > highScoreRef.current) {
          setHighScore(newScore)
          localStorage.setItem('snake-high-score', String(newScore))
        }

        // 更新 Combo
        setComboCount(newComboCount)
        setComboTimer(newComboTimer)
        setComboMultiplier(newComboMultiplier)

        // 重置方向变化标记
        directionChangeSinceLastEatRef.current = false

        // 更新统计
        if (isClutch) {
          setClutchCount((c) => c + 1)
          statsRef.current.clutch += 1
        }
        if (isSniper) {
          setSniperCount((c) => c + 1)
          statsRef.current.sniper += 1
        }
        if (isTrick) {
          setTrickCount((c) => c + 1)
          statsRef.current.trick += 1
        }
        if (newComboMultiplier > statsRef.current.maxCombo) {
          statsRef.current.maxCombo = newComboMultiplier
          setMaxCombo(newComboMultiplier)
        }

        // === Fever 触发检测 ===
        if (
          newComboCount >= FEVER_TRIGGER_COMBO &&
          !feverUsedRef.current &&
          !isFeverRef.current
        ) {
          setIsFever(true)
          setFeverUsed(true)
          setFeverTimeLeft(FEVER_DURATION_MS)
          isFeverRef.current = true
          feverUsedRef.current = true
          feverTimeLeftRef.current = FEVER_DURATION_MS
          statsRef.current.feverTriggered = true

          // Fever 期间刷新额外食物（保持 3 个）
          const remaining = currentFoods.filter((_, i) => i !== eatenFoodIndex)
          const need = 3 - remaining.length - 1 // 还需要补充几个（newSnake 头要避开）
          // 这里简化：移除被吃的，生成新食物
          const newFoods: Point[] = []
          for (let i = 0; i < 3; i++) {
            const avoid = newFoods.concat(newSnake)
            const newFood = randomFood(avoid, newSnake[0], 2)
            newFoods.push(newFood)
          }
          setFoods(newFoods)

          // Fever 触发飘字
          addFloatingText(
            'FEVER!',
            '6 秒无敌 × 双倍分',
            next.x,
            next.y,
            '#fbbf24',
            36
          )
        } else {
          // 普通刷新食物
          if (fever) {
            // Fever 期间保持 3 个食物
            const remaining = currentFoods.filter((_, i) => i !== eatenFoodIndex)
            const need = 3 - remaining.length
            const newFoods = [...remaining]
            for (let i = 0; i < need; i++) {
              const avoid = newFoods.concat(newSnake)
              const f = randomFood(avoid, newSnake[0], 2)
              newFoods.push(f)
            }
            setFoods(newFoods)
          } else {
            // 普通模式只 1 个食物
            const newFood = randomFood(newSnake, newSnake[0], 2)
            setFoods([newFood])
          }
        }

        setFoodEaten((c) => c + 1)
        lastEatTimeRef.current = now

        // 检查成就
        checkAchievements()

        // 防刷分：同方向超过 10 步，Combo 窗口减半
        if (consecutiveDirectionCountRef.current > 10) {
          setComboTimer((t) => Math.min(t, Math.floor(t / 2)))
        }
      }
    }

    const id = setInterval(tick, interval)
    return () => clearInterval(id)
  }, [status, level, comboCount, isFever, activeBuffs, addFloatingText, checkAchievements, applyPowerUp, hasBuff])

  // ============ Combo / Fever / 道具 计时器 ============
  useEffect(() => {
    if (status !== 'playing') return

    let lastTime = Date.now()
    const interval = setInterval(() => {
      const now = Date.now()
      const delta = now - lastTime
      lastTime = now

      const isFrozen = activeBuffsRef.current.some((b) => b.type === 'freeze')

      // Combo 倒计时（freeze 期间暂停）
      if (comboTimerRef.current > 0 && !isFrozen) {
        const newTimer = Math.max(0, comboTimerRef.current - delta)
        setComboTimer(newTimer)
        if (newTimer === 0) {
          // Combo 断了
          setComboCount(0)
          setComboMultiplier(1)
        }
      }

      // Fever 倒计时
      if (isFeverRef.current) {
        const newFever = Math.max(0, feverTimeLeftRef.current - delta)
        setFeverTimeLeft(newFever)
        if (newFever === 0) {
          setIsFever(false)
          isFeverRef.current = false
          // Fever 结束后食物恢复 1 个
          setFoods((prev) => prev.slice(0, 1))
        }
      }

      // 清理过期 buff
      const beforeCount = activeBuffsRef.current.length
      const filtered = activeBuffsRef.current.filter((b) => b.expiresAt > now)
      if (filtered.length !== beforeCount) {
        setActiveBuffs(filtered)
      }

      // 道具刷新逻辑
      if (!powerUpItemRef.current && now >= nextPowerUpSpawnRef.current) {
        // 随机选择道具类型（5 正 4 负，权重均等）
        const types: ItemType[] = ['shield', 'boost', 'double', 'shrink', 'freeze', 'poison', 'reverse', 'slow', 'fog']
        const chosenType = types[Math.floor(Math.random() * types.length)]
        const currentSnake = snakeRef.current
        const currentFoods = foodsRef.current
        // 在空位置生成
        const newPos = randomFood([...currentSnake, ...currentFoods], currentSnake[0], 3)
        const item: PowerUpItem = {
          pos: newPos,
          type: chosenType,
          expiresAt: now + POWERUP_LIFETIME,
        }
        setPowerUpItem(item)
        powerUpItemRef.current = item
        // 下次刷新时间
        nextPowerUpSpawnRef.current = now + POWERUP_SPAWN_MIN + Math.random() * (POWERUP_SPAWN_MAX - POWERUP_SPAWN_MIN)
      }

      // 道具过期消失
      if (powerUpItemRef.current && now > powerUpItemRef.current.expiresAt) {
        setPowerUpItem(null)
        powerUpItemRef.current = null
      }
    }, 50)

    return () => clearInterval(interval)
  }, [status])

  // ============ 重绘 ============
  useEffect(() => {
    draw()
    // 持续重绘（用于动画效果）
    let raf: number
    const loop = () => {
      draw()
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [draw])

  // ============ 控制 ============
  const handleStart = useCallback(() => {
    setSnake(INITIAL_SNAKE)
    const initFood = randomFood(INITIAL_SNAKE, { x: 8, y: 10 }, 3)
    setFoods([initFood])
    setDirection('RIGHT')
    nextDirectionRef.current = 'RIGHT'
    directionRef.current = 'RIGHT'
    lastDirRef.current = 'RIGHT'
    setScore(0)
    setFoodEaten(0)
    setComboCount(0)
    setComboTimer(0)
    setComboMultiplier(1)
    setIsFever(false)
    setFeverUsed(false)
    setFeverTimeLeft(0)
    isFeverRef.current = false
    feverUsedRef.current = false
    feverTimeLeftRef.current = 0
    comboCountRef.current = 0
    comboTimerRef.current = 0
    setClutchCount(0)
    setSniperCount(0)
    setTrickCount(0)
    setFeverScore(0)
    setMaxCombo(0)
    setFeverFoodsEaten(0)
    setFloatingTexts([])
    statsRef.current = {
      clutch: 0,
      sniper: 0,
      trick: 0,
      maxCombo: 0,
      feverTriggered: false,
      feverFoodsEaten: 0,
    }
    directionChangeSinceLastEatRef.current = false
    consecutiveDirectionCountRef.current = 0
    // 重置道具状态
    setPowerUpItem(null)
    powerUpItemRef.current = null
    setActiveBuffs([])
    activeBuffsRef.current = []
    setItemsCollected(0)
    // 第一个道具 8 秒后刷新
    nextPowerUpSpawnRef.current = Date.now() + 8000
    // 启动进场倒计时
    setStatus('countdown')
    setCountdownStage('3')
    let stage: CountdownStage = '3'
    const sequence: CountdownStage[] = ['3', '2', '1', 'GO']
    let idx = 0
    const tick = () => {
      idx++
      if (idx < sequence.length) {
        stage = sequence[idx]
        setCountdownStage(stage)
        timerId = window.setTimeout(tick, 700)
      } else {
        // GO 显示 400ms 后开始游戏
        timerId = window.setTimeout(() => {
          setCountdownStage(null)
          setStatus('playing')
        }, 400)
      }
    }
    let timerId = window.setTimeout(tick, 700)
  }, [])

  const handlePauseToggle = useCallback(() => {
    if (status === 'playing') setStatus('paused')
    else if (status === 'paused') setStatus('playing')
  }, [status])

  // 键盘控制
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const key = e.key
      const map: Record<string, Direction> = {
        ArrowUp: 'UP',
        ArrowDown: 'DOWN',
        ArrowLeft: 'LEFT',
        ArrowRight: 'RIGHT',
        w: 'UP',
        s: 'DOWN',
        a: 'LEFT',
        d: 'RIGHT',
      }
      if (map[key]) {
        e.preventDefault()
        if (statusRef.current !== 'playing') return
        let newDir = map[key]
        // 反向控制 buff
        if (activeBuffsRef.current.some((b) => b.type === 'reverse')) {
          newDir = REVERSE_DIR[newDir]
        }
        if (OPPOSITE[directionRef.current] === newDir) return
        nextDirectionRef.current = newDir
      }
      if (key === ' ' || key === 'Spacebar') {
        e.preventDefault()
        if (statusRef.current === 'playing' || statusRef.current === 'paused') {
          handlePauseToggle()
        }
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [handlePauseToggle])

  const changeDirection = (dir: Direction) => {
    if (status !== 'playing') return
    let newDir = dir
    if (activeBuffsRef.current.some((b) => b.type === 'reverse')) {
      newDir = REVERSE_DIR[newDir]
    }
    if (OPPOSITE[directionRef.current] === newDir) return
    nextDirectionRef.current = newDir
  }

  const statusLabel = {
    idle: '准备开始',
    countdown: '准备中',
    playing: '进行中',
    paused: '已暂停',
    over: '游戏结束',
  }[status]

  const comboTierColor = comboCount > 0 ? getComboTier(comboCount).color : '#94a3b8'
  const isNewRecord = status === 'over' && score > 0 && score === highScore && score > 0

  return (
    <div className="min-h-screen w-full cyber-grid-bg relative overflow-hidden" style={{ background: 'radial-gradient(ellipse at top, #0f0f25 0%, #050510 60%, #000005 100%)' }}>
      {/* 装饰：扫描线 */}
      <div className="scanline" />
      {/* 装饰：顶部光晕 */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] pointer-events-none" style={{ background: 'radial-gradient(ellipse, rgba(0, 255, 209, 0.15) 0%, transparent 70%)' }} />
      {/* 装饰：底部光晕 */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[200px] pointer-events-none" style={{ background: 'radial-gradient(ellipse, rgba(255, 0, 128, 0.08) 0%, transparent 70%)' }} />

      <div className="relative z-10 flex flex-col items-center px-4 py-8 sm:py-10">
        {/* ===== Hero 标题区 ===== */}
        <header className="text-center mb-6 sm:mb-8 hero-in">
          <div className="flex items-center justify-center gap-3 mb-2">
            <span className="text-[10px] tracking-[0.4em] uppercase font-mono-num text-cyan-300/70">ARCADE EDITION</span>
            <span className="text-[10px] text-cyan-500/50">·</span>
            <span className="text-[10px] tracking-[0.4em] uppercase font-mono-num text-pink-300/70">v2.0</span>
          </div>
          <div className="flex items-center justify-center gap-3 sm:gap-4 mb-2">
            <Gamepad2 className="h-8 w-8 sm:h-10 sm:w-10 text-cyan-400 neon-text-cyan neon-flicker" />
            <h1 className="text-5xl sm:text-7xl font-black tracking-wider neon-text-cyan neon-flicker" style={{ fontFamily: 'var(--font-geist-mono), monospace' }}>
              SNAKE
            </h1>
            <Apple className="h-8 w-8 sm:h-10 sm:w-10 text-pink-400 neon-text-pink" />
          </div>
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-cyan-400" />
            <h2 className="text-base sm:text-lg font-bold tracking-[0.3em] neon-text-pink">贪 吃 蛇</h2>
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-cyan-400" />
          </div>
          <p className="text-xs sm:text-sm text-cyan-200/60 tracking-wider font-mono-num">
            连击不断 · FEVER 高潮 · 隐藏成就 · 远不止是贪吃蛇
          </p>
        </header>

        <div className="w-full max-w-6xl flex flex-col lg:flex-row gap-5 items-start justify-center">
          {/* ===== 主舞台：Canvas 区 ===== */}
          <div className="w-full lg:w-auto flex flex-col gap-3 card-in" style={{ animationDelay: '0.1s' }}>
            {/* Combo 倒计时条 */}
            <ComboBar
              comboCount={comboCount}
              comboMultiplier={comboMultiplier}
              comboTimer={comboTimer}
              comboWindowMax={COMBO_WINDOW_MAX_MS}
              color={comboTierColor}
              isPlaying={status === 'playing'}
            />

            {/* Canvas 主舞台 */}
            <div className="relative" style={{ width: CANVAS_SIZE, maxWidth: '100%' }}>
              {/* 角落装饰 */}
              <div className="corner-deco corner-deco-tl" />
              <div className="corner-deco corner-deco-tr" />
              <div className="corner-deco corner-deco-bl" />
              <div className="corner-deco corner-deco-br" />

              {/* 主画布卡片 */}
              <div
                ref={containerRef}
                className="relative glass-card-strong rounded-lg overflow-hidden"
                style={{ width: CANVAS_SIZE, height: CANVAS_SIZE, maxWidth: '100%' }}
              >
                <canvas
                  ref={canvasRef}
                  width={CANVAS_SIZE}
                  height={CANVAS_SIZE}
                  className="block"
                  style={{
                    width: '100%',
                    height: 'auto',
                    aspectRatio: '1 / 1',
                    imageRendering: 'pixelated',
                  }}
                />

                {/* Fever 期间画布外光环 */}
                {isFever && (
                  <div
                    className="absolute inset-0 rounded-lg pointer-events-none fever-glow"
                  />
                )}

                {/* 飘字层 */}
                <FloatingTextLayer texts={floatingTexts} />

                {/* 进场倒计时特效 */}
                {status === 'countdown' && countdownStage && (
                  <CountdownOverlay stage={countdownStage} />
                )}

                {/* 覆盖层：未开始 / 暂停 / 结束 */}
                {status !== 'playing' && status !== 'countdown' && (
                  <Overlay
                    status={status}
                    score={score}
                    highScore={highScore}
                    maxCombo={maxCombo}
                    clutchCount={clutchCount}
                    sniperCount={sniperCount}
                    trickCount={trickCount}
                    feverScore={feverScore}
                    feverFoodsEaten={feverFoodsEaten}
                    itemsCollected={itemsCollected}
                    isNewRecord={isNewRecord}
                    onStart={handleStart}
                    onResume={handlePauseToggle}
                  />
                )}
              </div>
            </div>

            {/* Combo / Fever 状态徽章行 */}
            <div className="flex gap-2 flex-wrap items-center justify-center min-h-[28px]">
              {isFever && (
                <span className="tag-neon inline-flex items-center gap-1 px-3 py-1 rounded text-xs font-mono-num animate-pulse" style={{ color: '#ff0080' }}>
                  <Flame className="h-3 w-3" />
                  FEVER! {Math.ceil(feverTimeLeft / 1000)}s
                </span>
              )}
              {comboCount > 0 && (
                <span
                  className="tag-neon inline-flex items-center gap-1 px-3 py-1 rounded text-xs font-mono-num"
                  style={{
                    color: comboTierColor === 'rainbow' ? '#ffeb3b' : comboTierColor,
                  }}
                >
                  <Zap className="h-3 w-3" />
                  {comboCount} 连击 · {comboMultiplier}×
                </span>
              )}
              {comboCount === 0 && status === 'playing' && (
                <span className="text-xs text-cyan-500/40 font-mono-num tracking-wider">
                  &gt; 等待 Combo 启动...
                </span>
              )}
            </div>

            {/* 激活 Buff 状态栏 */}
            <ActiveBuffsBar buffs={activeBuffs} />
          </div>

          {/* ===== 右侧信息栏 ===== */}
          <div className="w-full lg:w-80 flex flex-col gap-4">
            {/* 实时状态 - Primary 卡 */}
            <div className="glass-card-strong rounded-xl p-4 relative card-in" style={{ animationDelay: '0.2s' }}>
              <div className="corner-deco corner-deco-tl" style={{ width: 16, height: 16 }} />
              <div className="corner-deco corner-deco-tr" style={{ width: 16, height: 16 }} />
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Trophy className="h-4 w-4 text-cyan-400" />
                  <h3 className="text-xs font-bold tracking-[0.3em] uppercase text-cyan-300 font-mono-num">SYSTEM STATUS</h3>
                </div>
                <span
                  className="tag-neon px-2 py-0.5 rounded text-[10px] font-mono-num font-bold"
                  style={{
                    color: status === 'playing' ? '#39ff14' : status === 'paused' ? '#ffeb3b' : status === 'over' ? '#ff0080' : '#6b7280',
                  }}
                >
                  {statusLabel}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <StatBlock label="当前分数" value={score} color="#00ffd1" icon={<Apple className="h-3.5 w-3.5" />} primary />
                <StatBlock label="最高分" value={highScore} color="#ffeb3b" icon={<Trophy className="h-3.5 w-3.5" />} primary />
                <StatBlock label="最高 Combo" value={maxCombo} suffix="×" color="#ff6b00" icon={<Zap className="h-3.5 w-3.5" />} />
                <StatBlock label="蛇身长度" value={snake.length} color="#b026ff" icon={<Gauge className="h-3.5 w-3.5" />} />
                <StatBlock label="险胜 Clutch" value={clutchCount} color="#ff0080" icon={<Flame className="h-3.5 w-3.5" />} />
                <StatBlock label="远距离 Snipe" value={sniperCount} color="#b026ff" icon={<Target className="h-3.5 w-3.5" />} />
                <StatBlock label="方向变化 Trick" value={trickCount} color="#ff6b00" icon={<Sparkles className="h-3.5 w-3.5" />} />
                <StatBlock label="Fever 得分" value={feverScore} color="#ffeb3b" icon={<Flame className="h-3.5 w-3.5" />} />
                <StatBlock label="道具收集" value={itemsCollected} color="#06b6d4" icon={<Sparkles className="h-3.5 w-3.5" />} />
                <StatBlock label="激活 Buff" value={activeBuffs.length} color="#3b82f6" icon={<Zap className="h-3.5 w-3.5" />} />
              </div>
            </div>

            {/* 操作 + 难度 合并卡 */}
            <div className="glass-card rounded-xl p-4 card-in" style={{ animationDelay: '0.3s' }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Play className="h-4 w-4 text-cyan-400" />
                  <h3 className="text-xs font-bold tracking-[0.3em] uppercase text-cyan-300 font-mono-num">CONTROL</h3>
                </div>
                <div className="flex items-center gap-2">
                  <Gauge className="h-3.5 w-3.5 text-cyan-400/70" />
                  <span className="text-[10px] font-mono-num text-cyan-300/70 tracking-wider">DIFFICULTY</span>
                </div>
              </div>
              {/* 主按钮 */}
              <div className="space-y-2 mb-3">
                {status === 'idle' && (
                  <button onClick={handleStart} className="neon-btn w-full py-2.5 rounded-md text-sm font-bold tracking-wider flex items-center justify-center gap-2">
                    <Play className="h-4 w-4" />
                    启 动 游 戏
                  </button>
                )}
                {status === 'countdown' && (
                  <button disabled className="neon-btn w-full py-2.5 rounded-md text-sm font-bold tracking-wider flex items-center justify-center gap-2 opacity-60 cursor-wait">
                    <Sparkles className="h-4 w-4 animate-pulse" />
                    准 备 中 ...
                  </button>
                )}
                {status === 'playing' && (
                  <button onClick={handlePauseToggle} className="neon-btn-pink w-full py-2.5 rounded-md text-sm font-bold tracking-wider flex items-center justify-center gap-2">
                    <Pause className="h-4 w-4" />
                    暂 停
                  </button>
                )}
                {status === 'paused' && (
                  <button onClick={handlePauseToggle} className="neon-btn w-full py-2.5 rounded-md text-sm font-bold tracking-wider flex items-center justify-center gap-2">
                    <Play className="h-4 w-4" />
                    继 续 游 戏
                  </button>
                )}
                {status === 'over' && (
                  <button onClick={handleStart} className="neon-btn w-full py-2.5 rounded-md text-sm font-bold tracking-wider flex items-center justify-center gap-2">
                    <RotateCcw className="h-4 w-4" />
                    再 玩 一 次
                  </button>
                )}
                {(status === 'playing' || status === 'paused') && (
                  <button onClick={handleStart} className="w-full py-1.5 rounded-md text-xs text-cyan-300/60 hover:text-cyan-300 transition-colors flex items-center justify-center gap-2 font-mono-num tracking-wider">
                    <RotateCcw className="h-3 w-3" />
                    RESET
                  </button>
                )}
              </div>
              {/* 分割线 */}
              <div className="h-px bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent mb-3" />
              {/* 难度选择 */}
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { l: 1, name: '休闲', color: '#39ff14' },
                  { l: 2, name: '普通', color: '#00ffd1' },
                  { l: 3, name: '挑战', color: '#ff6b00' },
                  { l: 4, name: '极速', color: '#ff0080' },
                ].map((opt) => (
                  <button
                    key={opt.l}
                    onClick={() => setLevel(opt.l)}
                    disabled={status === 'playing' || status === 'paused' || status === 'countdown'}
                    className={`flex flex-col items-center py-2 rounded-md border text-xs transition-all ${
                      level === opt.l
                        ? 'bg-white/5'
                        : 'border-cyan-500/10 text-cyan-300/40 hover:border-cyan-500/30'
                    } ${status === 'playing' || status === 'paused' || status === 'countdown' ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'}`}
                    style={level === opt.l ? {
                      borderColor: opt.color,
                      color: opt.color,
                      boxShadow: `0 0 10px ${opt.color}40, inset 0 0 8px ${opt.color}20`,
                      textShadow: `0 0 6px ${opt.color}80`,
                    } : undefined}
                  >
                    <span className="text-sm font-bold font-mono-num">{opt.l}</span>
                    <span className="mt-0.5 text-[10px]">{opt.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 成就图鉴 */}
            <div className="glass-card rounded-xl p-4 card-in" style={{ animationDelay: '0.5s' }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Trophy className="h-4 w-4 text-yellow-400 neon-text-yellow" />
                  <h3 className="text-xs font-bold tracking-[0.3em] uppercase text-cyan-300 font-mono-num">ACHIEVEMENTS</h3>
                </div>
                <span className="text-xs font-mono-num text-yellow-400 neon-text-yellow">
                  {unlockedAchievements.length}/{ACHIEVEMENTS.length}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {ACHIEVEMENTS.map((ach) => {
                  const unlocked = unlockedAchievements.includes(ach.id)
                  return (
                    <div
                      key={ach.id}
                      title={unlocked ? `${ach.name} - ${ach.description}` : '??? - 未解锁'}
                      className={`aspect-square flex flex-col items-center justify-center rounded-md border text-xl transition-all ${
                        unlocked
                          ? 'border-yellow-400 bg-yellow-400/10'
                          : 'border-cyan-500/10'
                      }`}
                      style={unlocked ? {
                        boxShadow: '0 0 12px rgba(255, 235, 59, 0.4), inset 0 0 8px rgba(255, 235, 59, 0.1)',
                      } : { opacity: 0.3 }}
                    >
                      <span>{unlocked ? ach.icon : '🔒'}</span>
                    </div>
                  )
                })}
              </div>
              <p className="text-[10px] text-cyan-300/40 mt-2 font-mono-num tracking-wider">
                &gt; 部分条件隐藏，尝试不同玩法解锁
              </p>
            </div>

            {/* 玩法说明 */}
            <div className="glass-card rounded-xl p-4 card-in" style={{ animationDelay: '0.6s' }}>
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="h-4 w-4 text-cyan-400" />
                <h3 className="text-xs font-bold tracking-[0.3em] uppercase text-cyan-300 font-mono-num">HOW TO PLAY</h3>
              </div>
              <div className="space-y-1.5 text-[11px] text-cyan-200/70">
                <p className="flex items-center gap-2">
                  <span className="text-cyan-500/50 font-mono-num">&gt;</span>
                  <kbd className="px-1.5 py-0.5 bg-cyan-500/10 rounded border border-cyan-500/30 text-[9px] font-mono-num text-cyan-300">↑↓←→</kbd>
                  /
                  <kbd className="px-1.5 py-0.5 bg-cyan-500/10 rounded border border-cyan-500/30 text-[9px] font-mono-num text-cyan-300">WASD</kbd>
                  <span className="text-cyan-300/50">移动</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-cyan-500/50 font-mono-num">&gt;</span>
                  <kbd className="px-1.5 py-0.5 bg-cyan-500/10 rounded border border-cyan-500/30 text-[9px] font-mono-num text-cyan-300">SPACE</kbd>
                  <span className="text-cyan-300/50">暂停/继续</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-cyan-500/50 font-mono-num">&gt;</span>
                  <span className="text-orange-400 font-medium">Combo</span>
                  <span className="text-cyan-300/50">连吃触发，倍率指数增长</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-cyan-500/50 font-mono-num">&gt;</span>
                  <span className="text-yellow-400 font-medium">Fever</span>
                  <span className="text-cyan-300/50">连吃 8 个，6 秒无敌 ×2</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-cyan-500/50 font-mono-num">&gt;</span>
                  <span className="text-pink-400 font-medium">⚡Clutch</span>
                  <span className="text-cyan-300/50">倒计时&lt;0.5s 吃到 ×1.5</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-cyan-500/50 font-mono-num">&gt;</span>
                  <span className="text-purple-400 font-medium">🏹Sniper</span>
                  <span className="text-cyan-300/50">食物≥5 格 ×1.3</span>
                </p>
                <p className="flex items-center gap-2">
                  <span className="text-cyan-500/50 font-mono-num">&gt;</span>
                  <span className="text-orange-400 font-medium">🔄Trick</span>
                  <span className="text-cyan-300/50">吃前转向 ×1.2</span>
                </p>
              </div>

              {/* 道具说明 */}
              <div className="mt-3 pt-3 border-t border-cyan-500/10">
                <div className="text-[10px] font-mono-num text-cyan-300/70 tracking-wider mb-2">POWER-UPS</div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[10px]">
                  <div className="flex items-center gap-1"><span>🛡️</span><span className="text-blue-400">护盾</span><span className="text-cyan-300/40">抗撞击</span></div>
                  <div className="flex items-center gap-1"><span>⚡</span><span className="text-yellow-400">加速</span><span className="text-cyan-300/40">+50%速</span></div>
                  <div className="flex items-center gap-1"><span>💎</span><span className="text-purple-400">双倍分</span><span className="text-cyan-300/40">×2</span></div>
                  <div className="flex items-center gap-1"><span>✂️</span><span className="text-emerald-400">缩短</span><span className="text-cyan-300/40">-3节</span></div>
                  <div className="flex items-center gap-1"><span>❄️</span><span className="text-cyan-400">冻结</span><span className="text-cyan-300/40">暂停Combo</span></div>
                  <div className="flex items-center gap-1"><span>💀</span><span className="text-fuchsia-700">毒蘑菇</span><span className="text-cyan-300/40">-30%分</span></div>
                  <div className="flex items-center gap-1"><span>🔄</span><span className="text-red-400">反向</span><span className="text-cyan-300/40">方向反</span></div>
                  <div className="flex items-center gap-1"><span>🐌</span><span className="text-gray-400">减速</span><span className="text-cyan-300/40">-50%速</span></div>
                  <div className="flex items-center gap-1 col-span-2"><span>🌫️</span><span className="text-slate-400">黑雾</span><span className="text-cyan-300/40">视野受限</span></div>
                </div>
              </div>

              {/* 移动端方向按钮 */}
              <div className="grid grid-cols-3 gap-2 mt-3 lg:hidden">
                <div />
                <DirectionButton dir="UP" onClick={changeDirection}>
                  <ArrowUp className="h-5 w-5" />
                </DirectionButton>
                <div />
                <DirectionButton dir="LEFT" onClick={changeDirection}>
                  <ArrowLeft className="h-5 w-5" />
                </DirectionButton>
                <DirectionButton dir="DOWN" onClick={changeDirection}>
                  <ArrowDown className="h-5 w-5" />
                </DirectionButton>
                <DirectionButton dir="RIGHT" onClick={changeDirection}>
                  <ArrowRight className="h-5 w-5" />
                </DirectionButton>
              </div>
            </div>
          </div>
        </div>

        {/* 成就解锁弹窗 */}
        {achievementToast && (
          <AchievementToast achievement={achievementToast} />
        )}

        <footer className="mt-10 flex items-center gap-3 text-[10px] text-cyan-500/40 font-mono-num tracking-wider">
          <span className="h-px w-12 bg-gradient-to-r from-transparent to-cyan-500/40" />
          <span>SYSTEM ONLINE · ACHIEVEMENTS & HIGH SCORE AUTO-SAVED</span>
          <span className="h-px w-12 bg-gradient-to-l from-transparent to-cyan-500/40" />
        </footer>
      </div>

      <style jsx global>{`
        @keyframes floatUp {
          0% {
            transform: translate(-50%, 0);
            opacity: 0;
          }
          15% {
            opacity: 1;
          }
          100% {
            transform: translate(-50%, -60px);
            opacity: 0;
          }
        }
        @keyframes achPop {
          0% {
            transform: translate(-50%, -50%) scale(0.3);
            opacity: 0;
          }
          60% {
            transform: translate(-50%, -50%) scale(1.15);
            opacity: 1;
          }
          100% {
            transform: translate(-50%, -50%) scale(1);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  )
}

// ============ 子组件：Combo 倒计时条 ============
function ComboBar({
  comboCount,
  comboMultiplier,
  comboTimer,
  comboWindowMax,
  color,
  isPlaying,
}: {
  comboCount: number
  comboMultiplier: number
  comboTimer: number
  comboWindowMax: number
  color: string
  isPlaying: boolean
}) {
  const ratio = comboCount > 0 ? comboTimer / comboWindowMax : 0
  const isLow = ratio > 0 && ratio < 0.2
  const isCritical = ratio > 0 && ratio < 0.1

  const barColor =
    ratio > 0.5 ? '#39ff14' : ratio > 0.3 ? '#ffeb3b' : ratio > 0 ? '#ff0080' : 'rgba(0, 255, 209, 0.2)'
  const bgColor = color === 'rainbow' ? '#ffeb3b' : color

  return (
    <div
      className="w-full glass-card rounded-md p-2 flex items-center gap-3"
      style={{ maxWidth: CANVAS_SIZE }}
    >
      {/* 倍率徽章 */}
      <div
        className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center font-bold text-sm border-2 font-mono-num"
        style={{
          borderColor: comboCount > 0 ? bgColor : 'rgba(0, 255, 209, 0.2)',
          color: comboCount > 0 ? bgColor : 'rgba(0, 255, 209, 0.3)',
          backgroundColor: comboCount > 0 ? `${bgColor}20` : 'transparent',
          transform: isCritical ? 'scale(1.08)' : 'scale(1)',
          transition: 'transform 0.15s ease',
          boxShadow: comboCount > 0 ? `0 0 12px ${bgColor}80, inset 0 0 8px ${bgColor}20` : 'none',
          textShadow: comboCount > 0 ? `0 0 6px ${bgColor}` : 'none',
        }}
      >
        {comboMultiplier}×
      </div>

      {/* 倒计时条 */}
      <div className="flex-1 relative">
        <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(0, 255, 209, 0.08)' }}>
          <div
            className="h-full rounded-full transition-all duration-75"
            style={{
              width: `${ratio * 100}%`,
              backgroundColor: barColor,
              boxShadow: `0 0 8px ${barColor}, 0 0 16px ${barColor}`,
              animation: isCritical ? 'feverPulse 0.3s ease-in-out infinite' : 'none',
            }}
          />
        </div>
        <div className="text-[10px] mt-1 flex justify-between font-mono-num">
          <span style={{ color: comboCount > 0 ? bgColor : 'rgba(0, 255, 209, 0.4)' }}>
            {comboCount > 0 ? `${comboCount} 连击` : isPlaying ? '> 等待 Combo...' : ''}
          </span>
          {comboCount > 0 && (
            <span
              className="font-bold"
              style={{ color: isLow ? '#ff0080' : 'rgba(0, 255, 209, 0.6)', textShadow: isLow ? '0 0 6px #ff0080' : 'none' }}
            >
              {(comboTimer / 1000).toFixed(1)}s
            </span>
          )}
        </div>
      </div>
    </div>
  )
}

// ============ 子组件：进场倒计时特效 ============
function CountdownOverlay({ stage }: { stage: CountdownStage }) {
  const isGo = stage === 'GO'
  const color = isGo ? '#39ff14' : stage === '1' ? '#ff0080' : stage === '2' ? '#ff6b00' : '#ffeb3b'
  const ringColor = isGo ? '#39ff14' : '#00ffd1'

  return (
    <div className="absolute inset-0 rounded-lg flex flex-col items-center justify-center pointer-events-none z-20" style={{ background: 'rgba(5, 5, 16, 0.6)', backdropFilter: 'blur(2px)' }}>
      {/* 外圈光环 */}
      <div
        className="absolute rounded-full"
        style={{
          width: 280,
          height: 280,
          border: `2px solid ${ringColor}`,
          boxShadow: `0 0 40px ${ringColor}80, inset 0 0 40px ${ringColor}40`,
          animation: 'countdownRing 0.7s ease-out',
        }}
      />
      {/* 第二圈 */}
      <div
        className="absolute rounded-full"
        style={{
          width: 200,
          height: 200,
          border: `1px solid ${ringColor}`,
          opacity: 0.5,
          animation: 'countdownRing 0.7s ease-out 0.1s backwards',
        }}
      />
      {/* 主数字 */}
      <div
        key={stage}
        className="relative font-black font-mono-num"
        style={{
          fontSize: isGo ? 96 : 140,
          color,
          textShadow: `0 0 20px ${color}, 0 0 40px ${color}, 0 0 60px ${color}80`,
          animation: 'countdownPop 0.5s cubic-bezier(0.25, 1, 0.5, 1)',
          letterSpacing: isGo ? '0.1em' : '0',
        }}
      >
        {stage}
      </div>
      {/* GO 时的副文字 */}
      {isGo && (
        <div
          className="absolute mt-32 text-sm font-mono-num tracking-[0.4em] uppercase"
          style={{
            color: '#00ffd1',
            textShadow: '0 0 8px #00ffd1',
            animation: 'countdownFadeIn 0.3s ease-out 0.1s backwards',
          }}
        >
          START
        </div>
      )}
    </div>
  )
}

// ============ 子组件：飘字层 ============
function FloatingTextLayer({ texts }: { texts: FloatingText[] }) {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {texts.map((t) => (
        <div
          key={t.id}
          className="absolute font-bold text-center select-none font-mono-num"
          style={{
            left: t.x,
            top: t.y,
            transform: 'translate(-50%, 0)',
            color: t.color,
            fontSize: `${t.size}px`,
            textShadow: `0 0 8px ${t.color}, 0 0 16px ${t.color}80, 0 2px 4px rgba(0,0,0,0.8)`,
            animation: 'floatUp 1.2s ease-out forwards',
            whiteSpace: 'nowrap',
          }}
        >
          <div>{t.text}</div>
          {t.subText && (
            <div style={{ fontSize: `${Math.max(10, t.size * 0.5)}px`, marginTop: '2px', opacity: 0.9 }}>
              {t.subText}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

// ============ 子组件：覆盖层 ============
function Overlay({
  status,
  score,
  highScore,
  maxCombo,
  clutchCount,
  sniperCount,
  trickCount,
  feverScore,
  feverFoodsEaten,
  itemsCollected,
  isNewRecord,
  onStart,
  onResume,
}: {
  status: GameStatus
  score: number
  highScore: number
  maxCombo: number
  clutchCount: number
  sniperCount: number
  trickCount: number
  feverScore: number
  feverFoodsEaten: number
  itemsCollected: number
  isNewRecord: boolean
  onStart: () => void
  onResume: () => void
}) {
  if (status === 'playing') return null

  return (
    <div className="absolute inset-0 rounded-lg flex flex-col items-center justify-center p-4 overflow-y-auto" style={{ background: 'rgba(5, 5, 16, 0.88)', backdropFilter: 'blur(8px)' }}>
      {/* 角落装饰 */}
      <div className="corner-deco corner-deco-tl" />
      <div className="corner-deco corner-deco-tr" />
      <div className="corner-deco corner-deco-bl" />
      <div className="corner-deco corner-deco-br" />

      {status === 'idle' && (
        <div className="flex flex-col items-center text-center">
          <div className="text-5xl mb-3 neon-text-cyan">🐍</div>
          <h2 className="text-2xl font-black mb-2 neon-text-cyan font-mono-num tracking-wider">READY?</h2>
          <p className="text-xs text-cyan-200/60 mb-5 max-w-xs font-mono-num tracking-wider">
            &gt; 连吃触发 Combo · 连吃 8 个进入 FEVER · 6 秒无敌双倍分 · 挑战极限操作
          </p>
          <button
            onClick={onStart}
            className="neon-btn px-8 py-3 rounded-md text-sm font-bold tracking-wider flex items-center gap-2"
          >
            <Play className="h-4 w-4" />
            启 动 游 戏
          </button>
        </div>
      )}

      {status === 'paused' && (
        <div className="flex flex-col items-center text-center">
          <Pause className="h-12 w-12 text-yellow-400 neon-text-yellow mb-3 animate-pulse" />
          <h2 className="text-2xl font-black mb-2 neon-text-yellow font-mono-num tracking-wider">PAUSED</h2>
          <p className="text-xs text-cyan-200/60 mb-5 font-mono-num">&gt; 按 SPACE 或点击下方继续</p>
          <button
            onClick={onResume}
            className="neon-btn px-8 py-3 rounded-md text-sm font-bold tracking-wider flex items-center gap-2"
          >
            <Play className="h-4 w-4" />
            继 续 游 戏
          </button>
        </div>
      )}

      {status === 'over' && (
        <div className="flex flex-col items-center w-full max-w-sm">
          <div className="text-5xl mb-1 neon-text-pink">💀</div>
          <h2 className="text-2xl font-black mb-2 neon-text-pink font-mono-num tracking-wider">GAME OVER</h2>
          {isNewRecord && score > 0 && (
            <div className="mb-3 px-3 py-1 rounded-full border border-yellow-400 text-yellow-400 neon-text-yellow text-xs font-mono-num font-bold animate-pulse tracking-widest">
              ★ NEW RECORD ★
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 w-full my-3">
            <div className="rounded-md p-3 text-center" style={{ background: 'rgba(0, 255, 209, 0.05)', border: '1px solid rgba(0, 255, 209, 0.2)' }}>
              <div className="text-[9px] text-cyan-300/60 uppercase tracking-widest font-mono-num">SCORE</div>
              <div className="text-2xl font-bold neon-text-cyan font-mono-num">{score}</div>
            </div>
            <div className="rounded-md p-3 text-center" style={{ background: 'rgba(255, 235, 59, 0.05)', border: '1px solid rgba(255, 235, 59, 0.2)' }}>
              <div className="text-[9px] text-yellow-300/60 uppercase tracking-widest font-mono-num">BEST</div>
              <div className="text-2xl font-bold neon-text-yellow font-mono-num">{highScore}</div>
            </div>
          </div>

          <div className="w-full rounded-md p-3 space-y-1.5 text-xs font-mono-num" style={{ background: 'rgba(0, 255, 209, 0.03)', border: '1px solid rgba(0, 255, 209, 0.1)' }}>
            <div className="flex justify-between">
              <span className="text-cyan-300/50">🔥 最高 Combo</span>
              <span className="font-bold text-orange-400">{maxCombo}×</span>
            </div>
            <div className="flex justify-between">
              <span className="text-cyan-300/50">⚡ 险胜 Clutch</span>
              <span className="font-bold text-pink-400">{clutchCount} 次</span>
            </div>
            <div className="flex justify-between">
              <span className="text-cyan-300/50">🏹 远距离 Snipe</span>
              <span className="font-bold text-purple-400">{sniperCount} 次</span>
            </div>
            <div className="flex justify-between">
              <span className="text-cyan-300/50">🔄 方向变化 Trick</span>
              <span className="font-bold text-orange-400">{trickCount} 次</span>
            </div>
            <div className="flex justify-between">
              <span className="text-cyan-300/50">🌈 Fever 得分</span>
              <span className="font-bold text-yellow-400">{feverScore}</span>
            </div>
            {feverFoodsEaten > 0 && (
              <div className="flex justify-between">
                <span className="text-cyan-300/50">🌋 Fever 期间吃食物</span>
                <span className="font-bold text-yellow-400">{feverFoodsEaten} 个</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-cyan-300/50">道具收集</span>
              <span className="font-bold text-cyan-400">{itemsCollected} 个</span>
            </div>
          </div>

          <button
            onClick={onStart}
            className="neon-btn mt-4 px-8 py-3 rounded-md text-sm font-bold tracking-wider flex items-center gap-2"
          >
            <RotateCcw className="h-4 w-4" />
            再 玩 一 次
          </button>
        </div>
      )}
    </div>
  )
}

// ============ 子组件：激活的 Buff 状态栏 ============
function ActiveBuffsBar({ buffs }: { buffs: ActiveBuff[] }) {
  if (buffs.length === 0) return null
  const now = Date.now()
  return (
    <div className="flex gap-2 flex-wrap items-center justify-center">
      {buffs.map((buff) => {
        const cfg = ITEM_CONFIG[buff.type]
        const remaining = Math.max(0, buff.expiresAt - now)
        const ratio = remaining / buff.duration
        const isPositive = cfg.positive
        return (
          <div
            key={buff.type}
            className="tag-neon inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-mono-num"
            style={{
              color: cfg.color,
              boxShadow: `0 0 8px ${cfg.glowColor}`,
            }}
          >
            <span className="text-sm">{cfg.icon}</span>
            <span className="font-bold">{cfg.name}</span>
            {buff.type === 'shield' ? (
              <span className="text-[10px] opacity-80">×{buff.shieldCharges ?? 0}</span>
            ) : (
              <span className="text-[10px] opacity-70 tabular-nums">{(remaining / 1000).toFixed(1)}s</span>
            )}
            {/* 进度小条 */}
            {buff.type !== 'shield' && (
              <span
                className="h-1 w-8 rounded-full overflow-hidden inline-block"
                style={{ background: 'rgba(255,255,255,0.1)' }}
              >
                <span
                  className="block h-full rounded-full"
                  style={{
                    width: `${ratio * 100}%`,
                    background: cfg.color,
                    boxShadow: `0 0 4px ${cfg.color}`,
                  }}
                />
              </span>
            )}
          </div>
        )
      })}
    </div>
  )
}

// ============ 子组件：成就弹窗 ============
function AchievementToast({ achievement }: { achievement: Achievement }) {
  return (
    <div
      className="fixed top-1/2 left-1/2 z-50 pointer-events-none"
      style={{
        transform: 'translate(-50%, -50%)',
      }}
    >
      <div
        className="rounded-xl p-5 border-2 flex items-center gap-4 min-w-[280px]"
        style={{
          animation: 'achPop 0.4s ease-out',
          background: 'linear-gradient(135deg, rgba(255, 235, 59, 0.15), rgba(255, 107, 0, 0.1))',
          backdropFilter: 'blur(16px)',
          borderColor: '#ffeb3b',
          boxShadow: '0 0 40px rgba(255, 235, 59, 0.5), 0 12px 40px rgba(0, 0, 0, 0.6), inset 0 0 20px rgba(255, 235, 59, 0.1)',
        }}
      >
        <div className="text-4xl" style={{ filter: 'drop-shadow(0 0 8px rgba(255, 235, 59, 0.8))' }}>{achievement.icon}</div>
        <div>
          <div className="text-[10px] uppercase tracking-widest text-yellow-300 font-bold font-mono-num" style={{ textShadow: '0 0 6px rgba(255, 235, 59, 0.6)' }}>
            ★ ACHIEVEMENT UNLOCKED ★
          </div>
          <div className="text-lg font-bold text-yellow-400 neon-text-yellow mt-1">{achievement.name}</div>
          <div className="text-xs text-yellow-200/80 mt-0.5">{achievement.description}</div>
        </div>
      </div>
    </div>
  )
}

// ============ 子组件：统计块 ============
function StatBlock({
  label,
  value,
  suffix,
  icon,
  color = '#00ffd1',
  primary = false,
}: {
  label: string
  value: number
  suffix?: string
  icon: React.ReactNode
  color?: string
  primary?: boolean
}) {
  return (
    <div
      className={`rounded-md p-2.5 border ${primary ? 'relative' : ''}`}
      style={{
        background: primary ? `rgba(${hexToRgb(color)}, 0.06)` : 'rgba(255, 255, 255, 0.02)',
        borderColor: primary ? `rgba(${hexToRgb(color)}, 0.25)` : 'rgba(0, 255, 209, 0.08)',
      }}
    >
      <div className="flex items-center gap-1 text-[10px] mb-1 uppercase tracking-wider font-mono-num" style={{ color: `rgba(${hexToRgb(color)}, 0.7)` }}>
        <span style={{ color }}>{icon}</span>
        <span className="truncate">{label}</span>
      </div>
      <div
        className="text-xl font-bold font-mono-num tabular-nums"
        style={{
          color,
          textShadow: `0 0 8px rgba(${hexToRgb(color)}, 0.5)`,
        }}
      >
        {value}
        {suffix}
      </div>
    </div>
  )
}

function hexToRgb(hex: string): string {
  const h = hex.replace('#', '')
  const r = parseInt(h.substring(0, 2), 16)
  const g = parseInt(h.substring(2, 4), 16)
  const b = parseInt(h.substring(4, 6), 16)
  return `${r}, ${g}, ${b}`
}

// ============ 子组件：移动端方向按钮 ============
function DirectionButton({
  dir,
  onClick,
  children,
}: {
  dir: Direction
  onClick: (dir: Direction) => void
  children: React.ReactNode
}) {
  return (
    <button
      onClick={() => onClick(dir)}
      className="aspect-square flex items-center justify-center rounded-md border text-cyan-300/70 hover:text-cyan-300 active:scale-95 transition-all"
      style={{
        borderColor: 'rgba(0, 255, 209, 0.3)',
        background: 'rgba(0, 255, 209, 0.05)',
      }}
      aria-label={dir}
    >
      {children}
    </button>
  )
}
